export const FireBaseConfig = {
  /* apiKey: "AIzaSyCd0wii8iVgaR8M5zpHraH7VrrHncjIjDE",
    authDomain: "blog-app-3cda4.firebaseapp.com",
    databaseURL: "https://blog-app-3cda4.firebaseio.com",
    projectId: "blog-app-3cda4",
    storageBucket: "blog-app-3cda4.appspot.com",
    messagingSenderId: "1045419816065", */

       apiKey: "AIzaSyCd0wii8iVgaR8M5zpHraH7VrrHncjIjDE",
    authDomain: "blog-app-3cda4.firebaseapp.com",
    databaseURL: "https://blog-app-3cda4.firebaseio.com",
    projectId: "blog-app-3cda4",
    storageBucket: "blog-app-3cda4.appspot.com",
    messagingSenderId: "1045419816065",
    appId: "1:1045419816065:web:6de6e8117841a8322bc980",
    
};
